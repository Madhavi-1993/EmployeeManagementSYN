package com.org.syn.serviceTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.org.syn.constants.MessageContants;
import com.org.syn.entity.Employee;
import com.org.syn.entity.Grade;
import com.org.syn.entity.Promotion;
import com.org.syn.entity.PromotionId;
import com.org.syn.exception.EmployeeNotFoundException;
import com.org.syn.model.request.EmployeeRequest;
import com.org.syn.model.response.EmployeeResponse;
import com.org.syn.repo.EmployeeRepo;
import com.org.syn.repo.PromotionRepo;
import com.org.syn.service.EmployeeService;

@SpringBootTest
class EmployeeServiceImplTest {
	
	@Autowired
	private EmployeeService employeeService;
	
	@MockBean
	private EmployeeRepo employeeRepo;
	
	@MockBean
	private PromotionRepo promoteRepo;
	
	Optional<Employee> employee;
	EmployeeRequest empRequest;


	@Test
	void testGetEmployeeById_success() throws EmployeeNotFoundException {
		EmployeeResponse empResponse = employeeService.getEmployeeById(1);
		assertEquals(employee.get().getFirstName(), empResponse.getEmpResBody().getFirstName());
		assertThat(empResponse).isNotNull();
	}
	
	@Test
	void testaddEmployee() {
		//String employee_name = "Aman";
		Mockito.when(employeeRepo.save(employee.get())).thenReturn(employee.get());
		String empResponse = employeeService.addEmployee(empRequest);
		assertEquals(empResponse, MessageContants.EMPLOYEE_ADD_SUCCESS_MESSAGE);
		assertThat(empResponse).isNotNull();
	}
	
	@Test
	void testpromoteEmployeeEmployee() {
		List<Employee> listofDPPromotionEmp = new ArrayList<>(
		        Arrays.asList(new Employee("Anil", "K", LocalDate.of(1994, 7, 5), LocalDate.of(2018, 9, 25), new Grade(5, "Analyst"), 9.0),
		        new Employee("Ram", "B", LocalDate.of(1993, 9, 15), LocalDate.of(2017, 10, 17), new Grade(8, "Business Analyst"), 21.0) ));
		
		List<Employee> listofJDPromotionEmp = new ArrayList<>(
		        Arrays.asList(new Employee("Kumar", "P", LocalDate.of(1996, 7, 6), LocalDate.of(2019, 9, 30), new Grade(4, "Analyst"), 9.0),
		            new Employee("Gopal", "P", LocalDate.of(1992, 11, 25), LocalDate.of(2016, 9, 19), new Grade(3, "Developer"), 11.0)));
		List<Promotion> listOfPromotion = new ArrayList<>();
		Promotion pro1 = new Promotion();
		Promotion pro2 = new Promotion();
		pro1.setPromotionId(new PromotionId(listofDPPromotionEmp.get(0), LocalDate.of(2019, 9, 30)));
		pro2.setPromotionId(new PromotionId(listofDPPromotionEmp.get(1), LocalDate.of(2016, 9, 19)));
		listOfPromotion.add(pro1);
		listOfPromotion.add(pro2);
		
		when(employeeRepo.findByScoreAndDPPromotion()).thenReturn(listofDPPromotionEmp);
		when(employeeRepo.findByScoreAndJDEmployee()).thenReturn(listofJDPromotionEmp);
		//when(promoteRepo.saveAll(listOfPromotion)).thenReturn(listOfPromotion);
		//when(employeeRepo.saveAll(listofJDPromotionEmp)).thenReturn(listofJDPromotionEmp);
		List<Employee> empResponse = employeeService.promoteEmployee();
		System.out.println(empResponse);
		assertEquals(listofJDPromotionEmp.size()+listofDPPromotionEmp.size(), empResponse.size());
		assertThat(empResponse).isNotNull();
	}
	
	@Test
	void testgetAllEmployeesSortByDOJ() {
		/*
		 * empRequestList = new ArrayList<>( Arrays.asList(new EmployeeRequest("Aman",
		 * "Raja", LocalDate.of(1994, 7, 5), LocalDate.of(2018, 9, 25), 5, 11,
		 * "Analyst"),new EmployeeRequest("Ram", "P", LocalDate.of(1990, 4, 5),
		 * LocalDate.of(2019, 9, 5), 6, 12, "Business Analyst") ));
		 */
		List<Employee> listofEmp = new ArrayList<>(
		        Arrays.asList(new Employee("Kumar", "P", LocalDate.of(1996, 7, 6), LocalDate.of(2019, 9, 30), new Grade(4, "Analyst"), 9.0),
		            new Employee("Gopal", "P", LocalDate.of(1992, 11, 25), LocalDate.of(2016, 9, 19), new Grade(3, "Developer"), 11.0)));
		
		Mockito.when(employeeRepo.findAll()).thenReturn(listofEmp);
		List<Employee> empResponse = employeeService.getAllEmployeesSortByDOJ();
		assertEquals(2, empResponse.size());
		assertThat(empResponse).isNotNull();
		assertEquals(listofEmp.get(1).getJoiningDate(),empResponse.get(0).getJoiningDate());
		//System.out.println(employeeService.promoteEmployee());
	}
	@Test
	void testThrowsEmployeeNotFoundEx() {
		//Mockito.when(employeeRepo.findById(10)).thenThrow(EmployeeNotFoundException.class);
		assertThrows(EmployeeNotFoundException.class, () -> {
			employeeService.getEmployeeById(10);
		});
		
		verify(employeeRepo, times(1)).findById(10);
	}

}
