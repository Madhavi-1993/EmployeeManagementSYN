package com.org.syn.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.org.syn.entity.Employee;
import com.org.syn.entity.Grade;
import com.org.syn.exception.EmployeeNotFoundException;
import com.org.syn.model.request.EmployeeRequest;
import com.org.syn.model.response.EmployeeResponse;
import com.org.syn.model.response.EmployeeResponseBody;
import com.org.syn.service.EmployeeService;

@WebMvcTest(EmployeeController.class)
class EmployeeControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private EmployeeService employeeService;

	@Autowired
	private ObjectMapper objectMapper;

	EmployeeResponse empResponse = new EmployeeResponse();
	EmployeeRequest empRequest;

	@BeforeEach
	void setup() throws EmployeeNotFoundException {
		EmployeeResponseBody empResponseBody = new EmployeeResponseBody("Aman", "Raja", LocalDate.of(1994, 7, 5),
				LocalDate.of(2018, 9, 25), 11, "Analyst");
		empResponse.setStatus("Success");
		empResponse.setStatusCode("200");
		empResponse.setEmpResBody(empResponseBody);
		empResponse.setMessage("employee found for Id:");

		/*
		 * empRequest = new EmployeeRequest("Aman", "Raja", LocalDate.of(1994, 7, 5),
		 * LocalDate.of(2018, 9, 25), 5, 11, "Analyst");
		 */
		Mockito.when(employeeService.getEmployeeById(1)).thenReturn(empResponse);
		Mockito.when(employeeService.addEmployee(empRequest)).thenReturn("Added.. Employee Successfully");
	}

	@Test
	void testgetEmployee() throws JsonProcessingException, Exception {
		// mockMvc.perform(MockMvcRequestBuilders.post("/employee/1").contentType(MediaType.APPLICATION_JSON)
		int id = 1;
		mockMvc.perform(get("/employee/{id}", id)).andExpect(status().isOk())
				// .contentType(MediaType.APPLICATION_JSON)
				// .content(objectMapper.writeValueAsString(empResponse)))
				.andExpect(jsonPath("$.empResBody.firstName").value(empResponse.getEmpResBody().getFirstName()))
				.andExpect(jsonPath("$.empResBody.lastName").value(empResponse.getEmpResBody().getLastName()))
				.andExpect(jsonPath("$.empResBody.rank").value(empResponse.getEmpResBody().getRank())).andDo(print());
	}

	@Test
	void shouldCreateEmployee() throws Exception {
		
		  mockMvc.perform(post("/employee/new")
		  .contentType(MediaType.APPLICATION_JSON)
		  .content("{\r\n" + "    \"firstName\":\"Aman\",\r\n" +
		  "    \"lastName\":\"Baita\",\r\n" + "    \"dateOfBirth\":\"1993-09-07\",\r\n"
		  + "    \"joiningDate\":\"2012-07-10\",\r\n" + "    \"score\": \"12\",\r\n" +
		  "    \"rank\": \"5\",\r\n" + "    \"role\":\"Senior Analyst\"\r\n" + "}")
		  .accept(MediaType.APPLICATION_JSON)) //
		 // .content(objectMapper.writeValueAsString(empRequest)))
		  .andExpect(status().isCreated()) .andDo(print());
	}
	
	@Test
	  void shouldReturnNotFoundEmployee() throws Exception {
	    int id = 13;
	    Mockito.when(employeeService.getEmployeeById(id)).thenReturn(new EmployeeResponse());
	    mockMvc.perform(get("/employee/{id}", id))
	         .andExpect(status().is(200))
	         .andDo(print());
	  }
	
	@Test
	  void testReturnListOfEmployee() throws Exception {
		List<Employee> listofEmp = new ArrayList<>(
	        Arrays.asList(new Employee("Aman1", "Raja", LocalDate.of(1994, 7, 5), LocalDate.of(2018, 9, 25), new Grade(5, "Analyst"), 9.0),
	        new Employee("Ram", "B", LocalDate.of(1993, 9, 15), LocalDate.of(2017, 10, 17), new Grade(8, "Analyst"), 21.0),
	            new Employee("Geetha", "P", LocalDate.of(1992, 11, 25), LocalDate.of(2016, 9, 19), new Grade(15, "Analyst"), 11.0)));
	   
		Mockito.when(employeeService.getAllEmployeesSortByDOJ()).thenReturn(listofEmp);
	    mockMvc.perform(get("/list"))
	        .andExpect(status().isOk())
	        .andExpect(jsonPath("$.empList.size()").value(listofEmp.size()))
	        .andDo(print());
	  }
	
	@Test
	  void testPromoteListOfEmployee() throws Exception {
		List<Employee> listofEmp = new ArrayList<>(
	        Arrays.asList(new Employee("Aarya", "B", LocalDate.of(1994, 7, 5), LocalDate.of(2018, 9, 25), new Grade(5, "Analyst"), 9.0),
	        new Employee("Darshit", "K", LocalDate.of(1993, 9, 15), LocalDate.of(2017, 10, 17), new Grade(8, "Analyst"), 21.0)
	            /*,new Employee("Rana", "P", LocalDate.of(1992, 11, 25), LocalDate.of(2016, 9, 19), new Grade(15, "Analyst"), 11.0)*/));
	   
		Mockito.when(employeeService.promoteEmployee()).thenReturn(listofEmp);
	    mockMvc.perform(get("/employee/promote"))
	        .andExpect(status().isOk())
	        .andExpect(jsonPath("$.empList.size()").value(listofEmp.size()))
	        .andDo(print());
	  }
}
