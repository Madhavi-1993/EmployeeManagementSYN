package com.org.syn.repositoryTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import com.org.syn.entity.Employee;
import com.org.syn.entity.Grade;
import com.org.syn.repo.EmployeeRepo;

@DataJpaTest
@AutoConfigureTestDatabase(replace= AutoConfigureTestDatabase.Replace.NONE)
class EmployeeRepoTest {
	
	@Autowired
	private EmployeeRepo employeeRepo;
	
	@Autowired
	private TestEntityManager testEntityManager;
	
	List<Employee> persistListofEmp;
	Employee emp;
	@BeforeEach
	void setup() {
		emp = new Employee("Aman", "Raja", LocalDate.of(1994, 7, 5), LocalDate.of(2018, 9, 25), new Grade(5, "Analyst"), 9.0);
		Employee employee = testEntityManager.persist(emp);
		System.out.println(employee);
		List<Employee> listofEmp = new ArrayList<>(
		        Arrays.asList(new Employee("Kumar", "P", LocalDate.of(1996, 7, 6), LocalDate.of(2019, 9, 30), new Grade(4, "Analyst"), 9.0),
		            new Employee("Gopal", "P", LocalDate.of(1992, 11, 25), LocalDate.of(2016, 9, 19), new Grade(3, "Developer"), 11.0),
		            new Employee("Anil", "K", LocalDate.of(1994, 7, 5), LocalDate.of(2018, 9, 25), new Grade(5, "Analyst"), 9.0),
			        new Employee("Ram", "B", LocalDate.of(1993, 9, 15), LocalDate.of(2017, 10, 17), new Grade(8, "Business Analyst"), 21.0)
		            ));
	}

	@Test
	void testfindbyId() {
		Employee emprepo = employeeRepo.findById(emp.getId()).get();
		assertEquals("Aman", emp.getFirstName());
		assertEquals(emp.getJoiningDate(), emprepo.getJoiningDate());
	}
	
	@Test
	void testSaveEmp() {
		Employee emprepo = employeeRepo.save(emp);
		assertEquals("Aman", emprepo.getFirstName());
		assertEquals(emp.getJoiningDate(), emprepo.getJoiningDate());
		assertThat(emprepo).isNotNull();
	}
	
	@Test
	void testFillAllEmp() {
		List<Employee> emprepo = employeeRepo.findAll();
		assertEquals("Aman", emprepo.get(0).getFirstName());
		//assertEquals(emp.getJoiningDate(), emprepo.getJoiningDate());
		assertThat(emprepo).isNotNull();
	}

}
