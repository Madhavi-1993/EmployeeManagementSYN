package com.org.syn.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.org.syn.entity.Employee;

@Repository
public interface EmployeeRepo extends JpaRepository<Employee, Integer>{


	List<Employee> findByScoreGreaterThan(Double d);
	
	@Query(value="SELECT * FROM EMPLOYEE  where score > 10 and ID not in (SELECT EMPLOYEE_ID  FROM PROMOTION) and  JOINING_DATE  <= dateadd(month, -8, now())", nativeQuery=true)
	List<Employee> findByScoreAndJDEmployee();
	
	@Modifying
	@Query(value="UPDATE EMPLOYEE SET SCORE=0 WHERE ID=:empId)",nativeQuery = true)
	void updateScoreToZero(@Param("empId") int id);
	
	@Query(value="SELECT * FROM EMPLOYEE WHERE score > 10 and ID IN (SELECT EMPLOYEE_ID  FROM  PROMOTION WHERE DATE_OF_PROMOTION   <= dateadd(month, -8, now()))",nativeQuery = true)
	List<Employee> findByScoreAndDPPromotion();
}
