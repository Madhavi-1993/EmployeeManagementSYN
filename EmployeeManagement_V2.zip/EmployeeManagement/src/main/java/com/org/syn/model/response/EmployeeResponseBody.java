package com.org.syn.model.response;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeResponseBody {

	private String firstName;
	private String lastName;
	private LocalDate dateOfBirth;
	private LocalDate joiningDate;
	private int rank;
	private String role;
	
}
