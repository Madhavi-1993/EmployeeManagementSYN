package com.org.syn.model.response;

import java.util.List;

import com.org.syn.entity.Employee;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class EmployeeListResponse {
	
	private String status;
	private String statusCode;
	private String message;
	private List<Employee> empList;

}
