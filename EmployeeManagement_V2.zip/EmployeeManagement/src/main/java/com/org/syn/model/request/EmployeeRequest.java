package com.org.syn.model.request;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeRequest {
	@NonNull
	private String firstName;
	private String lastName;
	@JsonFormat(pattern = "dd/MM/yyyy")
	private String dateOfBirth;
	@JsonFormat(pattern = "dd/MM/yyyy")
	private String joiningDate;
	private double score;
	private int rank;
	private String role;
}
