package com.org.syn.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.org.syn.constants.MessageContants;
import com.org.syn.entity.Employee;
import com.org.syn.exception.EmployeeNotFoundException;
import com.org.syn.exception.ValidationException;
import com.org.syn.model.request.EmployeeRequest;
import com.org.syn.model.response.EmployeeListResponse;
import com.org.syn.model.response.EmployeeResponse;
import com.org.syn.service.EmployeeService;
import com.org.syn.util.ValidationUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/")
public class EmployeeController {
	
	@Autowired
	private EmployeeService empService;
	
	@GetMapping("list")
	public EmployeeListResponse getAllEmployeesSortByDOJ(){
		log.debug("called /list mapping to rerive all employee data.");
		EmployeeListResponse employeeListResponse = new EmployeeListResponse();
		List<Employee> empList = empService.getAllEmployeesSortByDOJ();
		log.info("rerived all employee data."+empList);
		if(!empList.isEmpty()) {
			log.debug("Before setting status and message to response");
			employeeListResponse.setStatus(MessageContants.SUCCESS_MESSAGE);
			employeeListResponse.setStatusCode(MessageContants.SUCCESS_MESSAGE);
			employeeListResponse.setMessage(MessageContants.EMPLOYEE_SIZE + empList.size());
			employeeListResponse.setEmpList(empList);
			log.debug("After Setting status and message to response"+employeeListResponse);
		}else {
			log.debug("else Before setting status and message to response");
			employeeListResponse.setStatus(MessageContants.SUCCESS_MESSAGE);
			employeeListResponse.setStatusCode(MessageContants.SUCCESS_CODE);
			employeeListResponse.setMessage(MessageContants.NO_EMPLOYEES_FOUND);
			log.info(MessageContants.NO_EMPLOYEES_FOUND);
			log.debug("else After Setting status and message to response"+employeeListResponse);
		}
		return employeeListResponse;
	}
	
	@GetMapping("employee/{id}")
	public EmployeeResponse getEmployeeById(@PathVariable int id) throws EmployeeNotFoundException, ValidationException {
		log.debug("called employee/{"+id+"}");
		if(id<=0) {
			log.error("Id value is less than or equals 0");
			throw ValidationException.builder().status(422).message(MessageContants.EMPLOYEE_ID_ERROR).build();
		}
		log.debug("fetching employee by id");
		return empService.getEmployeeById(id);
	}
	
	@PostMapping("employee/new")
	@ResponseStatus(HttpStatus.CREATED)
	public String addEmployee(@RequestBody EmployeeRequest empRequest) throws ValidationException {
		log.debug("called employee/new");
		if(Boolean.TRUE.equals(ValidationUtil.isNullOrEmpty(empRequest.getFirstName()))) {
			log.error("Employee FirstName is null or empty please check json request");
			throw ValidationException.builder().status(422).message(MessageContants.FIRST_NAME_VALIDATION_MESSAGE).build();
		}
		if (ValidationUtil.isNotValidDate(empRequest.getDateOfBirth())) {
			log.error("Employee Date of Birth in wrong format or null please check json request");
			throw ValidationException.builder().status(422).message(MessageContants.DOB_VALIDATION_MESSAGE).build();
		}
		if (Boolean.TRUE.equals(ValidationUtil.isNullOrEmpty(empRequest.getJoiningDate()))) {
			log.error("Joining date in wrong format or null please check json request");
			throw ValidationException.builder().status(422).message(MessageContants.DOJ_VALIDATION_MESSAGE).build();
		}
		if(Boolean.TRUE.equals(ValidationUtil.isZeroOrEmpty(empRequest.getRank()))) {
			log.error("Employee Rank is null or empty please check json request");
			throw ValidationException.builder().status(422).message(MessageContants.RANK_VALIDATION_MESSAGE).build();
		}
		if(Boolean.TRUE.equals(ValidationUtil.isNullOrEmpty(empRequest.getRole()))) {
			log.error("Employee Role is null or empty please check json request");
			throw ValidationException.builder().status(422).message(MessageContants.ROLL_VALIDATION_MESSAGE).build();
		}
		log.info("employee added successfully");
		return empService.addEmployee(empRequest);
	}
	
	@GetMapping("employee/promote")
	public EmployeeListResponse promoteEmployee() {
		log.info("called employee/promote");
		EmployeeListResponse employeeListResponse = new EmployeeListResponse();
		List<Employee> empList = empService.promoteEmployee();
		log.info("got employee list for promotion"+empList);
		if(!empList.isEmpty()) {
			log.debug("Befor setting response for emplist:");
			employeeListResponse.setStatus(MessageContants.SUCCESS_MESSAGE);
			employeeListResponse.setStatusCode(MessageContants.SUCCESS_CODE);
			employeeListResponse.setMessage(MessageContants.EMPLOYEE_SIZE + empList.size());
			employeeListResponse.setEmpList(empList);
			log.debug("After setting response for emplist:"+employeeListResponse);
		}else {
			log.debug("else Befor setting response for emplist:");
			employeeListResponse.setStatus(MessageContants.SUCCESS_MESSAGE);
			employeeListResponse.setStatusCode(MessageContants.SUCCESS_CODE);
			employeeListResponse.setMessage(MessageContants.NO_EMPLOYEES_FOUND);
			log.debug("else After setting response for emplist:"+employeeListResponse);
		}
		return employeeListResponse;
	}
}
