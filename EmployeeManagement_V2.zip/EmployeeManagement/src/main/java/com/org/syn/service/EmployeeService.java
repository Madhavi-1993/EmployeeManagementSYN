package com.org.syn.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.syn.constants.MessageContants;
import com.org.syn.entity.Employee;
import com.org.syn.entity.Grade;
import com.org.syn.entity.Promotion;
import com.org.syn.entity.PromotionId;
import com.org.syn.exception.EmployeeNotFoundException;
import com.org.syn.model.request.EmployeeRequest;
import com.org.syn.model.response.EmployeeResponse;
import com.org.syn.model.response.EmployeeResponseBody;
import com.org.syn.repo.EmployeeRepo;
import com.org.syn.repo.PromotionRepo;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepo empRepo;

	@Autowired
	private PromotionRepo promoteRepo;

	public List<Employee> getAllEmployeesSortByDOJ() {
		log.info("getting all employees by sort by DOJ");
		return empRepo.findAll().stream().sorted(Comparator.comparing(Employee::getJoiningDate))
				.collect(Collectors.toList());
	}

	public EmployeeResponse getEmployeeById(int id) throws EmployeeNotFoundException {
		Employee employee = empRepo.findById(id).orElseThrow(()->
		new EmployeeNotFoundException(MessageContants.EMPLOYEE_NOT_FOUND_FOR_ID + id));
		log.info("got Employee By Id serivce layer "+id);
		EmployeeResponseBody employeeResponseBody = new EmployeeResponseBody();
		EmployeeResponse employeeResponse = new EmployeeResponse();
		if (employee != null) {
			log.info("setting Employee By Id serivce layer "+id);
			employeeResponseBody.setFirstName(employee.getFirstName());
			employeeResponseBody.setLastName(employee.getLastName());
			employeeResponseBody.setDateOfBirth(employee.getDateOfBirth());
			employeeResponseBody.setJoiningDate(employee.getJoiningDate());
			employeeResponseBody.setRank(employee.getGrade().getRank());
			employeeResponseBody.setRole(employee.getGrade().getRole());
			if(employeeResponseBody != null) {
				employeeResponse.setStatus(MessageContants.SUCCESS_MESSAGE);
				employeeResponse.setStatusCode(MessageContants.SUCCESS_CODE);
				employeeResponse.setMessage(MessageContants.EMPLOYEES_FOUND + id);
				employeeResponse.setEmpResBody(employeeResponseBody);
			}
		}
		else {
			employeeResponse.setStatus(MessageContants.SUCCESS_MESSAGE);
			employeeResponse.setStatusCode(MessageContants.SUCCESS_CODE);
			employeeResponse.setMessage(MessageContants.NO_EMPLOYEES_FOUND+id);
		}
		
		return employeeResponse;
	}

	public String addEmployee(EmployeeRequest empRequest) {
		Employee emp = new Employee();
		emp.setFirstName(empRequest.getFirstName());
		emp.setLastName(empRequest.getLastName());
		emp.setDateOfBirth(LocalDate.parse(empRequest.getDateOfBirth()));
		emp.setJoiningDate(LocalDate.parse(empRequest.getJoiningDate()));
		emp.setScore(empRequest.getScore());

		Grade grade = new Grade();
		grade.setRank(empRequest.getRank());
		grade.setRole(empRequest.getRole());

		emp.setGrade(grade);
		empRepo.save(emp);
		log.info(MessageContants.EMPLOYEE_ADD_SUCCESS_MESSAGE);
		return MessageContants.EMPLOYEE_ADD_SUCCESS_MESSAGE;
	}
		
	public List<Employee> promoteEmployee() {
		List<Employee> empListForPromotionEmpTable = promoteEmpFromJoiningDate();
		List<Employee> empListFrompromotionTable = promoteEmpFromDateOfPromotion();
		
		List<Employee> updatedEmpList = new ArrayList<>();
		List<Promotion> updatedPromoList = new ArrayList<>();
		
		
		for (Employee emp : empListForPromotionEmpTable) {
			emp.getGrade().setRank(emp.getGrade().getRank()+1);
			emp.setScore(0);
			updatedEmpList.add(emp);
			empRepo.save(emp);
			Promotion promotion = new Promotion();
			promotion.setPromotionId(new PromotionId(emp, LocalDate.now()));
			updatedPromoList.add(promotion);
		}
		for (Employee emp : empListFrompromotionTable) {
			emp.getGrade().setRank(emp.getGrade().getRank()+1);
			emp.setScore(0);
			updatedEmpList.add(emp);
			empRepo.save(emp);
			Promotion promotion = new Promotion();
			promotion.setPromotionId(new PromotionId(emp, LocalDate.now()));
			updatedPromoList.add(promotion);
		}
		promoteRepo.saveAll(updatedPromoList);
		log.info("Eligible employees promotion is completed.");
		return updatedEmpList;
	}

	public List<Employee> promoteEmpFromJoiningDate() {
		return empRepo.findByScoreAndJDEmployee();
	}

	public List<Employee> promoteEmpFromDateOfPromotion() {
		return empRepo.findByScoreAndDPPromotion();
	}

}
