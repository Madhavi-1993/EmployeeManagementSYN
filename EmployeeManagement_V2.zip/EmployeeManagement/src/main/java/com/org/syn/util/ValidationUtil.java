package com.org.syn.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.org.syn.constants.MessageContants;

public class ValidationUtil {
	
	public static Boolean isNullOrEmpty(String value) {
		return value == null || value.trim().length() == 0;
	}
	
	public static Boolean isZeroOrEmpty(int value) {
		return value == 0;
	}
	
	public static boolean isNotValidDate(String date) {
		boolean isNotValid = true;
		if (date == null) {
			isNotValid = true;
		} else {
			Matcher matcher = Pattern.compile(MessageContants.DATE_PATTERN).matcher(date);
			if (matcher.matches()) {
				isNotValid = false;
			}else {
				isNotValid = true;
			}
		}
		return isNotValid;
	}
}
