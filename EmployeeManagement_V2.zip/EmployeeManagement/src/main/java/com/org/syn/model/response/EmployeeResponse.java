package com.org.syn.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeResponse {
	
	private String status;
	private String statusCode;
	private String message;
	private EmployeeResponseBody empResBody;
	
}
