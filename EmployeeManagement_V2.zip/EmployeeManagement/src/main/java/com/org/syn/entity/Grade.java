package com.org.syn.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
@Entity
@Table(uniqueConstraints = { @UniqueConstraint(name = "UniqueRankAndRole", columnNames = { "rank", "role" }) })
public class Grade implements Serializable{
	
	private static final long serialVersionUID = 8217765709583609252L;
	@Id
	@Column(name = "grade_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int gradeId;
	int rank;
	String role;
	public Grade(int rank, String role) {
		super();
		log.info("grade constructor has initialized with rank and role");
		this.rank = rank;
		this.role = role;
	}
	
}

