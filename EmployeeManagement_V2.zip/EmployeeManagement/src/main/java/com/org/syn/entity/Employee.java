package com.org.syn.entity;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Entity
@Table(name="employee")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Slf4j
public class Employee implements Serializable{

	private static final long serialVersionUID = -5266162465410248736L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String firstName;
	private String lastName;
	private LocalDate dateOfBirth;
	private LocalDate joiningDate;
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "grade_id", referencedColumnName = "grade_id")
	private Grade grade;
	private double score;
	
	public Employee(String firstName, String lastName, LocalDate dateOfBirth, LocalDate joiningDate, Grade grade,
			double score) {
		super();
		log.info("Employee constructor has initialized");
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.joiningDate = joiningDate;
		this.grade = grade;
		this.score = score;
	}
	
	
	
}
