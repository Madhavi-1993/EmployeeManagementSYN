package com.org.syn.exception;

import java.io.IOException;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class DateValidationException extends IOException{

	private static final long serialVersionUID = -5309751456327611537L;

	private int status;
	private String message;
	
}
