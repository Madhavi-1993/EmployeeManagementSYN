package com.org.syn.service;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.syn.entity.Employee;
import com.org.syn.entity.Grade;
import com.org.syn.entity.Promotion;
import com.org.syn.entity.PromotionId;
import com.org.syn.exception.EmployeeNotFoundException;
import com.org.syn.model.request.EmployeeRequest;
import com.org.syn.model.response.EmployeeResponse;
import com.org.syn.model.response.EmployeeResponseBody;
import com.org.syn.repo.EmployeeRepo;
import com.org.syn.repo.GradeRepo;
import com.org.syn.repo.PromotionRepo;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepo empRepo;

	@Autowired
	private PromotionRepo promoteRepo;

	@Autowired
	private GradeRepo gradeRepo;

	public List<Employee> getAllEmployeesSortByDOJ() {
		return empRepo.findAll().stream().sorted(Comparator.comparing(Employee::getJoiningDate))
				.collect(Collectors.toList());
	}

	public EmployeeResponse getEmployeeById(int id) throws EmployeeNotFoundException {
		Employee employee = empRepo.findById(id)
				.orElseThrow(()-> new EmployeeNotFoundException("Employee not available for this id "+id));
		EmployeeResponseBody employeeResponseBody = new EmployeeResponseBody();
		EmployeeResponse employeeResponse = new EmployeeResponse();
		if (employee != null) {
			employeeResponseBody.setFirstName(employee.getFirstName());
			employeeResponseBody.setLastName(employee.getLastName());
			employeeResponseBody.setDateOfBirth(employee.getDateOfBirth());
			employeeResponseBody.setJoiningDate(employee.getJoiningDate());
			employeeResponseBody.setRank(employee.getGrade().getRank());
			employeeResponseBody.setRole(employee.getGrade().getRole());
			if(employeeResponseBody != null) {
				employeeResponse.setStatus("Success");
				employeeResponse.setStatusCode("200");
				employeeResponse.setMessage("employee found for Id: "+id);
				employeeResponse.setEmpResBody(employeeResponseBody);
			}
		}
		else {
			employeeResponse.setStatus("Success");
			employeeResponse.setStatusCode("200");
			employeeResponse.setMessage("No employee found for this Id: "+id);
		}
		
		return employeeResponse;
	}

	public String addEmployee(EmployeeRequest empRequest) {
		Employee emp = new Employee();
		emp.setFirstName(empRequest.getFirstName());
		emp.setLastName(empRequest.getLastName());
		emp.setDateOfBirth(empRequest.getDateOfBirth());
		emp.setJoiningDate(empRequest.getJoiningDate());
		emp.setScore(empRequest.getScore());

		Grade grade = new Grade();
		grade.setRank(empRequest.getRank());
		grade.setRole(empRequest.getRole());

		emp.setGrade(grade);
		empRepo.save(emp);
		return "Added.. Employee Successfully";
	}
	
	public List<Employee> addAllEmployee(List<EmployeeRequest> empreqList) {
		List<Employee> listEmp = new ArrayList<>();
		for(EmployeeRequest empRequest:empreqList) {
		Employee emp = new Employee();
		emp.setFirstName(empRequest.getFirstName());
		emp.setLastName(empRequest.getLastName());
		emp.setDateOfBirth(empRequest.getDateOfBirth());
		emp.setJoiningDate(empRequest.getJoiningDate());
		emp.setScore(empRequest.getScore());

		Grade grade = new Grade();
		grade.setRank(empRequest.getRank());
		grade.setRole(empRequest.getRole());

		emp.setGrade(grade);
		listEmp.add(emp);
		empRepo.save(emp);
		}
		//return "Added aLL EmployeeS Successfully";
		return listEmp;
	}
	
	public List<Employee> promoteEmployee() {
		List<Employee> empListForPromotionEmpTable = promoteEmpFromJoiningDate();
		List<Employee> empListFrompromotionTable = promoteEmpFromDateOfPromotion();
		
		List<Employee> updatedEmpList = new ArrayList<>();
		List<Promotion> updatedPromoList = new ArrayList<>();
		
		
		for (Employee emp : empListForPromotionEmpTable) {
			emp.getGrade().setRank(emp.getGrade().getRank()+1);
			emp.setScore(0);
			updatedEmpList.add(emp);
			empRepo.save(emp);
			Promotion promotion = new Promotion();
			promotion.setPromotionId(new PromotionId(emp, LocalDate.now()));
			updatedPromoList.add(promotion);
		}
		for (Employee emp : empListFrompromotionTable) {
			emp.getGrade().setRank(emp.getGrade().getRank()+1);
			emp.setScore(0);
			updatedEmpList.add(emp);
			empRepo.save(emp);
			Promotion promotion = new Promotion();
			promotion.setPromotionId(new PromotionId(emp, LocalDate.now()));
			updatedPromoList.add(promotion);
		}
		promoteRepo.saveAll(updatedPromoList);
		return updatedEmpList;
	}

	public List<Employee> promoteEmpFromJoiningDate() {
		List<Employee> listEmpScoreAndJD = empRepo.findByScoreAndJDEmployee();
		return listEmpScoreAndJD;
	}

	public List<Employee> promoteEmpFromDateOfPromotion() {
		List<Employee> listEmpScoreAndDp = empRepo.findByScoreAndDPPromotion();
		return listEmpScoreAndDp;
	}

}
