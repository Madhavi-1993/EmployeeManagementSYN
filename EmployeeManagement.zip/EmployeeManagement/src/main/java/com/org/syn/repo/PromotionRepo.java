package com.org.syn.repo;

import java.time.LocalDate;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.org.syn.entity.Promotion;
import com.org.syn.entity.PromotionId;

@Repository
public interface PromotionRepo extends JpaRepository<Promotion, PromotionId>{
	
	@Modifying
	@Query(value="UPDATE PROMOTION SET DATE_OF_PROMOTION  = :date  WHERE EMPLOYEE_ID = :empId)",nativeQuery = true)
	void updateRankIncrement(@Param("empId") int empId, @Param("date") LocalDate date);
	
}
