package com.org.syn.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.org.syn.entity.Employee;
import com.org.syn.exception.EmployeeNotFoundException;
import com.org.syn.model.request.EmployeeRequest;
import com.org.syn.model.response.EmployeeListResponse;
import com.org.syn.model.response.EmployeeResponse;
import com.org.syn.service.EmployeeService;

@RestController
@RequestMapping("/")
public class EmployeeController {
	
	@Autowired
	private EmployeeService empService;
	
	@GetMapping("list")
	public EmployeeListResponse getAllEmployeesSortByDOJ(){
		EmployeeListResponse employeeListResponse = new EmployeeListResponse();
		List<Employee> empList = empService.getAllEmployeesSortByDOJ();
		if(empList.size()!=0) {
			employeeListResponse.setStatus("Success");
			employeeListResponse.setStatusCode("200");
			employeeListResponse.setMessage("employees size: "+empList.size());
			employeeListResponse.setEmpList(empList);
		}else {
			employeeListResponse.setStatus("Success");
			employeeListResponse.setStatusCode("200");
			employeeListResponse.setMessage("No employees found.");
		}
		return employeeListResponse;
	}
	
	@GetMapping("employee/{id}")
	public EmployeeResponse getEmployeeById(@PathVariable int id) throws EmployeeNotFoundException {
		EmployeeResponse empResBody = empService.getEmployeeById(id);
		return empResBody;
	}
	
	@PostMapping("employee/new")
	@ResponseStatus(HttpStatus.CREATED)
	public String addEmployee(@RequestBody EmployeeRequest empRequest) {
		return empService.addEmployee(empRequest);
	}
	
	@PostMapping("employee/addall")
	public String addAllEmployee(@RequestBody List<EmployeeRequest> empList) {
		 empService.addAllEmployee(empList);
		 return "All Employees added successfully";
	}
	
	@GetMapping("employee/promote")
	public EmployeeListResponse promoteEmployee() {
		EmployeeListResponse employeeListResponse = new EmployeeListResponse();
		List<Employee> empList = empService.promoteEmployee();
		if(empList.size()!=0) {
			employeeListResponse.setStatus("Success");
			employeeListResponse.setStatusCode("200");
			employeeListResponse.setMessage("employees size: "+empList.size());
			employeeListResponse.setEmpList(empList);
		}else {
			employeeListResponse.setStatus("Success");
			employeeListResponse.setStatusCode("200");
			employeeListResponse.setMessage("No Employees eligible for Promotion.");
		}
		return employeeListResponse;
	}
}
