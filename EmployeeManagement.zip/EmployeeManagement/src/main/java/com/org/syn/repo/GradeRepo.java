package com.org.syn.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.org.syn.entity.Grade;

@Repository
public interface GradeRepo extends JpaRepository<Grade, Integer>{
		
	@Modifying
	@Query(value="UPDATE GRADE SET RANK=:rank WHERE GRADE_ID=:gradeId",nativeQuery = true)
	void updateRankIncrement(@Param("rank") int rank, @Param("gradeId") int gradeId);
}
