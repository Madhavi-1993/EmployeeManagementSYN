package com.org.syn.model.response;

import java.time.LocalDate;
import java.util.List;

import com.org.syn.entity.Employee;

public class EmployeeListResponse {
	
	private String status;
	private String statusCode;
	private String message;
	private List<Employee> empList;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<Employee> getEmpList() {
		return empList;
	}
	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}

}
