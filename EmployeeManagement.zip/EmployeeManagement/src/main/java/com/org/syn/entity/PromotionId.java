package com.org.syn.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;

@Embeddable
public class PromotionId implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	//@MapsId
	//@Column(name="employee_id")
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "employee_id", referencedColumnName = "id") 
	private Employee employee;
	LocalDate dateOfPromotion;
	
	public PromotionId() {

	}
	

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public LocalDate getDateOfPromotion() {
		return dateOfPromotion;
	}

	public void setDateOfPromotion(LocalDate dateOfPromotion) {
		this.dateOfPromotion = dateOfPromotion;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public PromotionId(Employee employee, LocalDate dateOfPromotion) {
		this.employee = employee;
		this.dateOfPromotion = dateOfPromotion;
	}

	@Override
	public int hashCode() {
		return Objects.hash(dateOfPromotion, employee);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PromotionId other = (PromotionId) obj;
		return Objects.equals(dateOfPromotion, other.dateOfPromotion) && Objects.equals(employee, other.employee);
	}

}
