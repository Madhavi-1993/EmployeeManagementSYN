package com.org.syn.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(uniqueConstraints = { @UniqueConstraint(name = "UniqueRankAndRole", columnNames = { "rank", "role" }) })
public class Grade {
	@Id
	@Column(name = "grade_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int gradeId;
	int rank;
	String role;
	
	/*
	 * @OneToOne
	 * 
	 * @MapsId
	 * 
	 * @JoinColumn(name = "grade_id") private Employee employee;
	 */
	
	public int getId() {
		return gradeId;
	}
	public void setId(int id) {
		this.gradeId = id;
	}
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	public Grade(int gradeId, int rank, String role) {
		super();
		this.gradeId = gradeId;
		this.rank = rank;
		this.role = role;
	}
	public Grade(int rank, String role) {
		this.rank = rank;
		this.role = role;
	}
	public Grade() {
		// TODO Auto-generated constructor stub
	}
	
	
}

