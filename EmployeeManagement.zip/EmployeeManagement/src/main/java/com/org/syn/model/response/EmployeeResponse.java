package com.org.syn.model.response;

public class EmployeeResponse {
	
	private String status;
	private String statusCode;
	private String message;
	private EmployeeResponseBody empResBody;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public EmployeeResponseBody getEmpResBody() {
		return empResBody;
	}
	public void setEmpResBody(EmployeeResponseBody empResBody) {
		this.empResBody = empResBody;
	}
	

}
