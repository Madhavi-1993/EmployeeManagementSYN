package com.org.syn.exception;

public class EmployeeNotFoundException extends Exception {

	private static final long serialVersionUID = -9079454849611061074L;

	public EmployeeNotFoundException() {
		super();
	}

	public EmployeeNotFoundException(String message) {
		super(message);
	}

}