package com.org.syn.model.response;

import java.time.LocalDate;

public class EmployeeResponseBody {

	private String firstName;
	private String lastName;
	private LocalDate dateOfBirth;
	private LocalDate joiningDate;
	private int rank;
	private String role;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public LocalDate getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(LocalDate joiningDate) {
		this.joiningDate = joiningDate;
	}
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public EmployeeResponseBody(String firstName, String lastName, LocalDate dateOfBirth, LocalDate joiningDate,
			int rank, String role) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.joiningDate = joiningDate;
		this.rank = rank;
		this.role = role;
	}
	public EmployeeResponseBody() {
		// TODO Auto-generated constructor stub
	}

	
}
