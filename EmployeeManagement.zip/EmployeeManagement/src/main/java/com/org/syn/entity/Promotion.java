package com.org.syn.entity;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;

@Entity
public class Promotion {
	@EmbeddedId
	private PromotionId promotionId;
	
	
	
	//  @OneToOne(cascade = CascadeType.ALL)
	 // @JoinColumn(name = "employee_id", referencedColumnName = "employee_id") 
	//  private Employee employee;
	 
	public Promotion() {
	}

	public PromotionId getPromotionId() {
		return promotionId;
	}

	public void setPromotionId(PromotionId promotionId) {
		this.promotionId = promotionId;
	}
	
	
}
