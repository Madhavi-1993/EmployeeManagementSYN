package com.org.syn.serviceTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.org.syn.constants.MessageContants;
import com.org.syn.entity.Employee;
import com.org.syn.entity.Grade;
import com.org.syn.entity.Promotion;
import com.org.syn.entity.PromotionId;
import com.org.syn.exception.EmployeeNotFoundException;
import com.org.syn.exception.ValidationException;
import com.org.syn.model.request.EmployeeRequest;
import com.org.syn.model.response.EmployeeListResponse;
import com.org.syn.model.response.EmployeeResponse;
import com.org.syn.repo.EmployeeRepo;
import com.org.syn.repo.PromotionRepo;
import com.org.syn.service.EmployeeService;

@SpringBootTest
@TestInstance(Lifecycle.PER_CLASS)
class EmployeeServiceTest {

	@Autowired
	private EmployeeService employeeService;

	@MockBean
	private EmployeeRepo employeeRepo;

	@MockBean
	private PromotionRepo promotionRepo;

	Optional<Employee> employee;
	EmployeeRequest empRequest;
	List<Employee> employeeList = new ArrayList<Employee>();
	List<Employee> listofEmp = new ArrayList<>();
	
	Promotion promotion;
	
	List<EmployeeRequest> empRequestList= new ArrayList<EmployeeRequest>();
	List<Promotion> promotionList= new ArrayList<Promotion>();
	
	@BeforeAll
	void saveEmployeeTest() {
		employee= Optional.of(Employee.builder()
				.id(1)
				.firstName("Madhavi")
				.lastName("Potraka")
				.dateOfBirth(LocalDate.of(1996, 7, 6))
				.joiningDate(LocalDate.of(2018, 9, 24))
				.grade(Grade.builder().rank(8).role("SA").build())
				.score(14)
				.build());
		Optional<Employee> employee1= Optional.of(Employee.builder()
				.id(1)
				.firstName("Madhavi")
				.lastName("Potraka")
				.dateOfBirth(LocalDate.of(1996, 7, 6))
				.joiningDate(LocalDate.of(2018, 9, 24))
				.grade(Grade.builder().rank(8).role("SA").build())
				.score(14)
				.build());
		employeeList.add(employee.get());
		employeeList.add(employee1.get());
		//employeeRepo.save(employee);
		
		empRequest = EmployeeRequest.builder()
				.firstName("Madhavi")
				.lastName("Potraka")
				.dateOfBirth("1996-07-06")
				.joiningDate("2018-09-24")
				.rank(8)
				.role("SA")
				.score(14)
				.build();
		
	
	  promotion = Promotion.builder() .promotionId(PromotionId.builder()
	  .dateOfPromotion(LocalDate.of(2019, 9,24)).employee(employee.get()).build()).build(); 
	  
	 Promotion promotion1 = Promotion.builder() .promotionId(PromotionId.builder()
			  .dateOfPromotion(LocalDate.of(2020, 8,14)).employee(employee.get()).build()).build(); 
	  //promotionRepo.save(promotion);
	  promotionList.add(promotion);
	  promotionList.add(promotion1);
	  
	  empRequestList = new ArrayList<>( Arrays.asList(new EmployeeRequest("Aman","Raja", "1994-07-05","2018-09-25", 5, 11,"Analyst"),
				new EmployeeRequest("Ram", "P","1990-04-05","2019-09-05", 6, 12, "Business Analyst") ));
	 
	  listofEmp = new ArrayList<>(Arrays.asList( Employee.builder().firstName("Kumar")
			  .lastName("P").dateOfBirth(LocalDate.of(1996, 7, 6)).joiningDate(LocalDate.of(2021,9,30))
			  .score(11.0).grade(Grade.builder().rank(3).role("Developer").build()).build(),
			  Employee.builder().firstName("Navi")
			  .lastName("R").dateOfBirth(LocalDate.of(1998,07,16)).joiningDate(LocalDate.of(2020,8, 13))
			  .score(13.0).grade(Grade.builder().rank(4).role("Sr Developer").build()).build()
			  ));
	
	}
	
	@Test
	void testGetEmployeeById_success() throws EmployeeNotFoundException, ValidationException {
		Mockito.when(employeeRepo.findById(Mockito.anyInt())).thenReturn(employee);
		EmployeeResponse empResponse = employeeService.getEmployeeById(1);
		
		assertEquals(employee.get().getFirstName(), empResponse.getEmpResBody().getFirstName());
		assertThat(empResponse).isNotNull();
		assertEquals(employee.get().getJoiningDate(), empResponse.getEmpResBody().getJoiningDate());
	}
	
	@Test
	void testGetEmployeeById_exception() throws EmployeeNotFoundException, ValidationException {
		Exception exception = assertThrows(ValidationException.class, ()->{
			employeeService.getEmployeeById(0);
		});
		assertEquals(MessageContants.EMPLOYEE_ID_ERROR, exception.getMessage());
	}

	@Test
	void testaddEmployee() throws ValidationException { 
		// String employee_name = "Aman";
		Mockito.when(employeeRepo.save(Mockito.any(Employee.class))).thenReturn(employee.get());
		String empResponse = employeeService.addEmployee(empRequest);
		assertEquals(empResponse, MessageContants.EMPLOYEE_ADD_SUCCESS_MESSAGE);
		assertThat(empResponse).isNotNull();
	}
	@Test
	void testaddAllEmployee() throws ValidationException { 
		// String employee_name = "Aman";
		Mockito.when(employeeRepo.saveAll(Mockito.anyList())).thenReturn(employeeList);
		List<Employee> empResponse = employeeService.addAllEmployee(empRequestList);
		assertEquals(empResponse.size(), 2);
		assertThat(empResponse).isNotNull();
	}
	
	@Test void testpromoteEmployeeEmployee() { 
		List<Employee> listofDPPromotionEmp = new ArrayList<>( Arrays.asList(new Employee("Anil",
				"K", LocalDate.of(1994, 7, 5), LocalDate.of(2018, 9, 25), new Grade(5,
						"Analyst"), 9.0), new Employee("Ram", "B", LocalDate.of(1993, 9, 15),
								LocalDate.of(2017, 10, 17), new Grade(8, "Business Analyst"), 21.0) ));
  
		/*
		 * List<Employee> listofJDPromotionEmp = new ArrayList<>( Arrays.asList(new
		 * Employee("Kumar", "P", LocalDate.of(1996, 7, 6), LocalDate.of(2019, 9, 30),
		 * new Grade(4, "Analyst"), 9.0), new Employee("Gopal", "P", LocalDate.of(1992,
		 * 11, 25), LocalDate.of(2016, 9, 19), new Grade(3, "Developer"), 11.0)));
		 */
		List<Promotion> listOfPromotion = new ArrayList<>(); Promotion pro1 = new
				Promotion(); Promotion pro2 = new Promotion(); pro1.setPromotionId(new
						PromotionId(listofDPPromotionEmp.get(0), LocalDate.of(2019, 9, 30)));
				pro2.setPromotionId(new PromotionId(listofDPPromotionEmp.get(1),
						LocalDate.of(2016, 9, 19))); listOfPromotion.add(pro1);
						listOfPromotion.add(pro2);
  
						//when(employeeRepo.findByScoreAndDPPromotion()).thenReturn(listofDPPromotionEmp);
						//when(employeeRepo.findByScoreAndJDEmployee()).thenReturn(listofJDPromotionEmp); 
						//when(promoteRepo.saveAll(listOfPromotion)).thenReturn(listOfPromotion);
						//when(employeeRepo.saveAll(listofJDPromotionEmp)).thenReturn(
						//listofJDPromotionEmp); List<Employee> empResponse = employeeService.promoteEmployee();
								//System.out.println(empResponse);
								//assertEquals(listofJDPromotionEmp.size()+listofDPPromotionEmp.size(),
									//	empResponse.size()); assertThat(empResponse).isNotNull(); 
		}

	@Test void testgetAllEmployeesSortByDOJ() {
	  Mockito.when(employeeRepo.findAll()).thenReturn(listofEmp); 
	  EmployeeListResponse empListResponse = employeeService.getAllEmployeesSortByDOJ(); 
	  assertEquals(2,empListResponse.getEmpList().size());
	  assertThat(empListResponse).isNotNull();
	  assertEquals(listofEmp.get(1).getJoiningDate(),empListResponse.getEmpList().get(0).getJoiningDate());
	  //System.out.println(employeeService.promoteEmployee());
	 }

	@Test 
	void testThrowsEmployeeNotFoundEx() {
		int id =10;
		Exception exception = assertThrows(EmployeeNotFoundException.class, ()->{
			employeeService.getEmployeeById(id);
		});
		assertEquals(MessageContants.EMPLOYEE_NOT_FOUND_FOR_ID+ id, exception.getMessage());
		
		verify(employeeRepo, times(1)).findById(10); 
	}
	
	@Test
	void testPromoteEmployee() {
		Mockito.when(employeeRepo.findByScoreGreaterThanAndJoiningDateBefore(Mockito.anyDouble(), Mockito.any()))
		.thenReturn(employeeList);
		
		Mockito.when(promotionRepo.findAll()).thenReturn(promotionList);
		
		Mockito.when(promotionRepo.findByPromotionIdDateOfPromotionBefore(Mockito.any()))
		.thenReturn(promotionList);
		
		Mockito.when(employeeRepo.findByScoreGreaterThan(Mockito.anyDouble()))
		.thenReturn(employeeList);
		EmployeeListResponse empListResponse = employeeService.promoteEmployee();
		
		assertEquals(2,empListResponse.getEmpList().size());
		assertThat(empListResponse).isNotNull();
		assertEquals(employeeList.get(1).getJoiningDate(),empListResponse.getEmpList().get(0).getJoiningDate());
		
	}
	@Test
	void testMapEmpListToEmpListResponse() {
		EmployeeListResponse empListResponse = employeeService.mapEmpListToEmpListResponse(employeeList);
		
		assertEquals(2,empListResponse.getEmpList().size());
		assertThat(empListResponse.getEmpList()).isNotEmpty();
		assertThat(empListResponse.getStatus()).isEqualTo(MessageContants.SUCCESS_MESSAGE);
		assertThat(empListResponse.getMessage()).isEqualTo(MessageContants.EMPLOYEE_SIZE+ empListResponse.getEmpList().size());
	}
	
	@Test
	void testMapEmployeeToEmployeeResponse() {
		Employee emp= null;
		EmployeeResponse empResponse = employeeService.mapEmployeeToEmployeeResponse(emp);
		
		assertThat(empResponse.getStatusCode()).isEqualTo(MessageContants.SUCCESS_CODE);
		assertThat(empResponse.getMessage()).isEqualTo(MessageContants.NO_EMPLOYEES_FOUND);
	}
	
	

}
