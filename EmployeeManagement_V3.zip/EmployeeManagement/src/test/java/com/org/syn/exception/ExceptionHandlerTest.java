package com.org.syn.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.org.syn.controller.EmployeeController;
import com.org.syn.repo.EmployeeRepo;
import com.org.syn.repo.PromotionRepo;

class ExceptionHandlerTest {
	
	@MockBean
	private ExceptionHandlerControllerAdvice exHandlerControllerAdvice;

	@MockBean
	private EmployeeRepo employeeRepo;

	@MockBean
	private PromotionRepo promotionRepo;
	
	@Before(value = "mock")
	void setUp() {
		MockMvc mock=MockMvcBuilders
	    .standaloneSetup(new EmployeeController())
	    .setControllerAdvice(new ExceptionHandlerControllerAdvice())
	    .build();
	}
	

	@Test 
	void testNullPointerEx() {
		NullPointerException ex = null;
		HttpServletRequest req = null;
			Mockito.when(exHandlerControllerAdvice.handleNullPointer(Mockito.any(), Mockito.any()))
			.thenThrow(NullPointerException.class);
			
			ResponseEntity<ExceptionResponse> responseEntity = exHandlerControllerAdvice.handleNullPointer(ex, req);
	
			assertEquals(responseEntity.getBody().getErrorMessage(), ex.getMessage());

	}
}
