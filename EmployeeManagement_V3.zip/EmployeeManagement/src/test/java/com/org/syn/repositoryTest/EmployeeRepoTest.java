package com.org.syn.repositoryTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.org.syn.entity.Employee;
import com.org.syn.entity.Grade;
import com.org.syn.entity.Promotion;
import com.org.syn.entity.PromotionId;
import com.org.syn.repo.EmployeeRepo;
import com.org.syn.repo.PromotionRepo;

//@SpringBootTest
@DataJpaTest
@TestInstance(Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class EmployeeRepoTest {
	
	@Autowired
	private EmployeeRepo employeeRepo;
	
	@Autowired
	private PromotionRepo promotionRepo;
	/*
	 * @Autowired private TestEntityManager testEntityManager;
	 */
	@BeforeAll
	void saveEmployeeTest() {
		Employee emp= Employee.builder()
				.firstName("Madhavi")
				.lastName("Potraka")
				.dateOfBirth(LocalDate.of(1996, 7, 6))
				.joiningDate(LocalDate.of(2018, 9, 24))
				.grade(Grade.builder().rank(8).role("SA").build())
				.score(14)
				.build();
		employeeRepo.save(emp);
		
		Promotion promotion = Promotion.builder()
				.promotionId(PromotionId.builder()
						.dateOfPromotion(LocalDate.of(2019, 9, 24)).employee(emp).build()).build();
		promotionRepo.save(promotion);
		assertThat(emp.getId()).isGreaterThan(0);
	}
	
	@Test
	@Order(2)
	void testgetAllEmployee() {
		List<Employee> listEmp = employeeRepo.findAll();
		System.out.println("list of emp madahvi"+listEmp);
	}
	
//	@BeforeEach
//	void setup() {
//		emp = new Employee("Aman", "Raja", LocalDate.of(1994, 7, 5), LocalDate.of(2018, 9, 25), new Grade(5, "Analyst"), 9.0);
//		Employee employee = testEntityManager.persist(emp);
//		System.out.println(employee);
//		List<Employee> listofEmp = new ArrayList<>(
//		        Arrays.asList(new Employee("Kumar", "P", LocalDate.of(1996, 7, 6), LocalDate.of(2019, 9, 30), new Grade(4, "Analyst"), 9.0),
//		            new Employee("Gopal", "P", LocalDate.of(1992, 11, 25), LocalDate.of(2016, 9, 19), new Grade(3, "Developer"), 11.0),
//		            new Employee("Anil", "K", LocalDate.of(1994, 7, 5), LocalDate.of(2018, 9, 25), new Grade(5, "Analyst"), 9.0),
//			        new Employee("Ram", "B", LocalDate.of(1993, 9, 15), LocalDate.of(2017, 10, 17), new Grade(8, "Business Analyst"), 21.0)
//		            ));
//	}

	@Test
	@Order(3)
	void testfindByScore() {
		List<Employee> listEmp = employeeRepo.findByScoreGreaterThan(7.0);
		System.out.println("testing:"+listEmp.size());
		
		assertEquals("Madhavi", listEmp.get(0).getFirstName());
		assertEquals(LocalDate.of(2018, 9, 24), listEmp.get(0).getJoiningDate());
		
	}
	
	@Test
	@Order(4)
	void testfindByJDBefore() {
		List<Employee> listEmp = employeeRepo.findByJoiningDateBefore(LocalDate.of(2020, 9, 24).minusMonths(8));
		System.out.println("testing:"+listEmp.size());
		
		assertEquals("Madhavi", listEmp.get(0).getFirstName());
		assertEquals(LocalDate.of(2018, 9, 24), listEmp.get(0).getJoiningDate());
		
	}
	
	@Test
	@Order(5)
	void testfindByDateOfPromoteBefore() {
		List<Promotion> listPromotion = promotionRepo.findByPromotionIdDateOfPromotionBefore(LocalDate.of(2020, 9, 24).minusMonths(8));
		System.out.println("testing:"+listPromotion.size());
		
		assertEquals("Madhavi", listPromotion.get(0).getPromotionId().getEmployee().getFirstName());
		assertThat(LocalDate.of(2018, 9, 24)).isBefore(listPromotion.get(0).getPromotionId().getDateOfPromotion());
		
	}
	
	@Test
	@Order(6)
	void testfindByScoreandJD() {
		List<Employee> listEmp = employeeRepo.findByScoreGreaterThanAndJoiningDateBefore(7.0, LocalDate.of(2020, 9, 24).minusMonths(8));
		System.out.println("testing:"+listEmp.size());
		
		assertEquals("Madhavi", listEmp.get(0).getFirstName());
		assertEquals(LocalDate.of(2018, 9, 24), listEmp.get(0).getJoiningDate());
		
	}
	
	@Test
	@Order(7)
	void testfindbyId() {
		Employee emprepo = employeeRepo.findById(1).get();
		System.out.println(emprepo);
		assertEquals("Madhavi", emprepo.getFirstName());
		assertEquals(LocalDate.of(2018, 9, 24), emprepo.getJoiningDate());
	}
	
	/*
	 * @Test void testSaveEmp() { Employee emprepo = employeeRepo.save(emp);
	 * assertEquals("Aman", emprepo.getFirstName());
	 * assertEquals(emp.getJoiningDate(), emprepo.getJoiningDate());
	 * assertThat(emprepo).isNotNull(); }
	 */
	
	@Test
	@Order(8)
	void testFillAllEmp() {
		List<Employee> emprepo = employeeRepo.findAll();
		assertEquals("Madhavi", emprepo.get(0).getFirstName());
		//assertEquals(emp.getJoiningDate(), emprepo.getJoiningDate());
		assertThat(emprepo).isNotNull();
	}
	@Test
	@Order(9)
	void testPromotionTblall() {
		List<Promotion> listPromote = promotionRepo.findAll();
		assertThat(listPromote.size()).isEqualTo(1);
	}

}
