package com.org.syn.repo;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.org.syn.entity.Employee;

@Repository
public interface EmployeeRepo extends JpaRepository<Employee, Integer>{


	List<Employee> findByScoreGreaterThan(Double d);
	
	List<Employee>  findByJoiningDateBefore(LocalDate date);
	
	List<Employee> findByScoreGreaterThanAndJoiningDateBefore(Double score, LocalDate date);
	
	/*
	 * @Modifying
	 * 
	 * @Query(value="update Employee e SET e.score=0 WHERE e.id=:empId") void
	 * updateScoreToZero(@Param("empId") int id);
	 */
	
}
