package com.org.syn.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.syn.constants.MessageContants;
import com.org.syn.entity.Employee;
import com.org.syn.entity.Grade;
import com.org.syn.entity.Promotion;
import com.org.syn.entity.PromotionId;
import com.org.syn.exception.EmployeeNotFoundException;
import com.org.syn.exception.ValidationException;
import com.org.syn.model.request.EmployeeRequest;
import com.org.syn.model.response.EmployeeListResponse;
import com.org.syn.model.response.EmployeeResponse;
import com.org.syn.model.response.EmployeeResponseBody;
import com.org.syn.repo.EmployeeRepo;
import com.org.syn.repo.PromotionRepo;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepo empRepo;

	@Autowired
	private PromotionRepo promoteRepo;

//	Sorting here with respect employee date of joinging
	public EmployeeListResponse getAllEmployeesSortByDOJ() {
		log.info("getting all employees by sort by DOJ");
		List<Employee> empList = empRepo.findAll().stream().sorted(Comparator.comparing(Employee::getJoiningDate))
				.collect(Collectors.toList());
		return mapEmpListToEmpListResponse(empList);
	}

	//getting employee with corresponding id,and mapping to EmployeeResponse
	public EmployeeResponse getEmployeeById(int id) throws EmployeeNotFoundException, ValidationException {
		if (id <= 0) {
			log.error("Id value is less than or equals 0");
			throw ValidationException.builder().status(422).message(MessageContants.EMPLOYEE_ID_ERROR).build();
		}
		log.debug("fetching employee by id");
		Employee employee = empRepo.findById(id)
				.orElseThrow(() -> EmployeeNotFoundException.builder().status(422).message(MessageContants.EMPLOYEE_NOT_FOUND_FOR_ID + id).build());
		log.info("got Employee By Id serivce layer " + id);
		return mapEmployeeToEmployeeResponse(employee);
	}
	//Adding employee to db and mapping EmployeeRequest to Employee
	public String addEmployee(EmployeeRequest empRequest) throws ValidationException {
		log.info("employee added successfully");
		empRepo.save(mapEmpRequestToEmployee(empRequest));
		log.info(MessageContants.EMPLOYEE_ADD_SUCCESS_MESSAGE);
		return MessageContants.EMPLOYEE_ADD_SUCCESS_MESSAGE;
	}
	//Adding all employees to db and mapping EmployeeRequest to Employee
	public List<Employee> addAllEmployee(List<EmployeeRequest> empreqList) {
		log.info("called addAllEmployee method.");
		return empRepo.saveAll(empreqList.stream().map(this::mapEmpRequestToEmployee).toList());
	}

	public EmployeeListResponse promoteEmployee() {
		List<Employee> promoteEmpListRes = new ArrayList<>();
		/*
		 * getting employee data from employee table where employeeId not existed in
		 * promotion table, score should be greater than 10 and Joining date should be
		 * before 8 months
		 */
		List<Employee> score10AndJoiningDate8MempList = empRepo.findByScoreGreaterThanAndJoiningDateBefore(10.0, LocalDate.now().minusMonths(8));
		
		List<Promotion> promotionList = promoteRepo.findAll();
		List<Integer> empIdsFromPromoton = promotionList.stream().map(promotion->promotion.getPromotionId().getEmployee().getId()).toList();
		
		List<Employee> score10AndJD8MAndNotinPromoteTblempList = score10AndJoiningDate8MempList.stream().filter(emp->!empIdsFromPromoton.contains(emp.getId())).toList();
		System.out.println(score10AndJD8MAndNotinPromoteTblempList);
		
		List<Employee> empListFromEmpTbltoPromote = score10AndJD8MAndNotinPromoteTblempList.stream()
				.map(this::updateEmpTblAndPromoteTbl).toList();
		
		/*
		 * getting employee data from promotion table where employeeId existed in
		 * employee table, score should be greater than 10 and dateofPromotion should be
		 * before 8 months
		 */
		
		List<Integer> empIdsFromPromotonforDP = promoteRepo.findByPromotionIdDateOfPromotionBefore(LocalDate.now().minusMonths(8)).stream()
				.map(promotion->promotion.getPromotionId().getEmployee().getId()).toList();
		
		List<Employee> score10AndDP8MAndInPromoteTblempList = empRepo.findByScoreGreaterThan(10.0).stream()
				.filter(emp->empIdsFromPromotonforDP.contains(emp.getId())).toList();
				
		List<Employee> empListFromPromoteTbltoPromote = score10AndDP8MAndInPromoteTblempList.stream()
				.map(this::updateEmpTblAndPromoteTbl).toList();
		
		

		/*
		 * List<Employee> updatedEmpListFromPromoteTbl =
		 * empRepo.findByScoreAndDPfromPromotion().stream()
		 * .map(this::updateEmpTblAndPromoteTbl).toList();
		 */
		
		promoteEmpListRes.addAll(empListFromEmpTbltoPromote);
		promoteEmpListRes.addAll(empListFromPromoteTbltoPromote);
		log.info("Eligible employees promotion is completed.");
		log.info("got employee list for promotion size:" + promoteEmpListRes.size());

		return mapEmpListToEmpListResponse(promoteEmpListRes);
	}

	/* Updating Employee and promotion table with score 0 and rank with +1, Promotion table with current date */ 
	public Employee updateEmpTblAndPromoteTbl(Employee emp) {
		emp.setScore(0);
		emp.getGrade().setRank(emp.getGrade().getRank() + 1);
		empRepo.save(emp);
		Promotion promotion = Promotion.builder()
				.promotionId(PromotionId.builder().employee(emp).dateOfPromotion(LocalDate.now()).build()).build();
		promoteRepo.save(promotion);
		return emp;
	}

	// Mapping List of Employee to  EmployeeListResponse
	public EmployeeListResponse mapEmpListToEmpListResponse(List<Employee> empList) {
		EmployeeListResponse employeeListResponse;
		if (!empList.isEmpty()) {
			log.debug("Before setting status and message to response");
			employeeListResponse = EmployeeListResponse.builder().status(MessageContants.SUCCESS_MESSAGE)
					.statusCode(MessageContants.SUCCESS_CODE).message(MessageContants.EMPLOYEE_SIZE + empList.size())
					.empList(empList).build();
			log.debug("After Setting status and message to response" + employeeListResponse);
		} else {
			log.debug("else Before setting status and message to response");

			employeeListResponse = EmployeeListResponse.builder().status(MessageContants.SUCCESS_MESSAGE)
					.statusCode(MessageContants.SUCCESS_CODE).message(MessageContants.NO_EMPLOYEES_FOUND).build();
			log.info(MessageContants.NO_EMPLOYEES_FOUND);
			log.debug("else After Setting status and message to response" + employeeListResponse);
		}
		return employeeListResponse;
	}

	//Mapping Employee to  EmployeeResponse
	public EmployeeResponse mapEmployeeToEmployeeResponse(Employee employee) {

		EmployeeResponse employeeResponse = null;
		if (employee != null) {
			log.info("setting Employee By Id serivce layer " + employee.getId());
			EmployeeResponseBody employeeResponseBody = EmployeeResponseBody.builder()
					.firstName(employee.getFirstName()).lastName(employee.getLastName())
					.dateOfBirth(employee.getDateOfBirth()).joiningDate(employee.getJoiningDate())
					.rank(employee.getGrade().getRank()).role(employee.getGrade().getRole()).build();
			if (employeeResponseBody != null) {
				employeeResponse = EmployeeResponse.builder().message(MessageContants.SUCCESS_MESSAGE)
						.statusCode(MessageContants.SUCCESS_CODE)
						.message(MessageContants.EMPLOYEES_FOUND + employee.getId()).empResBody(employeeResponseBody)
						.build();
			}
		} else {
			employeeResponse = EmployeeResponse.builder().message(MessageContants.SUCCESS_MESSAGE).statusCode(MessageContants.SUCCESS_CODE)
					.message(MessageContants.NO_EMPLOYEES_FOUND).build();
		}
		return employeeResponse;
	}
	
	//Mapping EmployeeRequest to  Employee
	public Employee mapEmpRequestToEmployee(EmployeeRequest empRequest) {
		return Employee.builder().firstName(empRequest.getFirstName()).lastName(empRequest.getLastName())
				.dateOfBirth(LocalDate.parse(empRequest.getDateOfBirth()))
				.joiningDate(LocalDate.parse(empRequest.getJoiningDate())).score(empRequest.getScore())
				.grade(Grade.builder().rank(empRequest.getRank()).role(empRequest.getRole()).build()).build();
	}

}
