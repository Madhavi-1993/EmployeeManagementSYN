package com.org.syn.repo;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.org.syn.entity.Promotion;
import com.org.syn.entity.PromotionId;

@Repository
public interface PromotionRepo extends JpaRepository<Promotion, PromotionId>{
	
	List<Promotion>  findByPromotionIdDateOfPromotionBefore(LocalDate date);
	
	/*
	 * @Modifying
	 * 
	 * @Query(
	 * value="update PROMOTION SET DATE_OF_PROMOTION  = :date  WHERE EMPLOYEE_ID = :empId)"
	 * ,nativeQuery = true) void updateRankIncrement(@Param("empId") int
	 * empId, @Param("date") LocalDate date);
	 */
	
}
