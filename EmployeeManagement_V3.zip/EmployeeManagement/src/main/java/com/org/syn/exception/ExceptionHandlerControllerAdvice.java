package com.org.syn.exception;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.org.syn.constants.MessageContants;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ControllerAdvice
public class ExceptionHandlerControllerAdvice extends ResponseEntityExceptionHandler {
	/* if NullPointerException throws comes here */
	@ExceptionHandler(NullPointerException.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public ResponseEntity<ExceptionResponse> handleNullPointer(NullPointerException exception,
			final HttpServletRequest request) {
		log.info("Exception handling for NullPointerException");
		ExceptionResponse error = new ExceptionResponse();
		error.setErrorMessage(exception.getMessage());
		error.setRequestedURI(request.getRequestURI());
		error.setError(exception.getClass().toString());
		error.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		log.debug("Exception handling for NullPointerException" + error.getErrorMessage());
		return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/* if DataIntegrityViolationException throws comes here -- suppose data violation with primary key */
	@ExceptionHandler(DataIntegrityViolationException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public ResponseEntity<ExceptionResponse> handleDataIntegrityViolation(DataIntegrityViolationException exception,
			final HttpServletRequest request) {
		log.info("Exception handling for DataIntegrityViolationException");
		ExceptionResponse error = new ExceptionResponse();
		error.setErrorMessage(MessageContants.RANK_ROLE_UNIQUE_CONSTRAIN_VAILATION_EX);
		error.setRequestedURI(request.getRequestURI());
		error.setError(exception.getClass().toString());
		error.setStatus(HttpStatus.BAD_REQUEST.value());
		log.debug("Exception handling for DataIntegrityViolationException" + error.getErrorMessage());
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}

	/* if EmployeeNotFoundException throws it will call here -- if employee not found form db*/
	@ExceptionHandler(EmployeeNotFoundException.class)
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	public ResponseEntity<ExceptionResponse> handleEmployeeNotFound(EmployeeNotFoundException exception,
			final HttpServletRequest request) {
		log.info("Exception handling for EmployeeNotFoundException");
		ExceptionResponse error = new ExceptionResponse();
		error.setErrorMessage(exception.getMessage());
		error.setRequestedURI(request.getRequestURI());
		error.setError(exception.getClass().toString());
		error.setStatus(HttpStatus.NOT_FOUND.value());
		log.debug("Exception handling for EmployeeNotFoundException" + error.getErrorMessage());
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}

	/* if handleException throws it will call here -- any exception throws which is not handing here*/
	@ExceptionHandler(Exception.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public ResponseEntity<ExceptionResponse> handleException(Exception exception, final HttpServletRequest request) {
		log.info("Exception handling for Exception");
		ExceptionResponse error = new ExceptionResponse();
		error.setErrorMessage(exception.getMessage());
		error.setRequestedURI(request.getRequestURI());
		error.setError(exception.getClass().toString());
		error.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		log.debug("Exception handling for Exception" + error.getErrorMessage());
		return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/* if InvalidFormatException throws it will call here -- if JSON format not valid*/
	@ExceptionHandler(InvalidFormatException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public ResponseEntity<ExceptionResponse> handleDateFormateException(InvalidFormatException exception,
			final HttpServletRequest request) {
		log.info("Exception handling for InvalidFormatException");
		ExceptionResponse error = new ExceptionResponse();
		error.setErrorMessage(exception.getMessage());
		error.setRequestedURI(request.getRequestURI());
		error.setError(exception.getClass().toString());
		error.setStatus(HttpStatus.BAD_REQUEST.value());
		log.debug("Exception handling for InvalidFormatException" + error.getErrorMessage());
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}

	/* if ValidationException throws it will call here -- it will validate input employee request formats*/
	@ExceptionHandler(ValidationException.class)
	@ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
	public ResponseEntity<ExceptionResponse> handleValidationException(ValidationException exception,
			final HttpServletRequest request) {
		log.info("Exception handling for ValidationException");
		ExceptionResponse error = new ExceptionResponse();
		error.setErrorMessage(exception.getMessage());
		error.setRequestedURI(request.getRequestURI());
		error.setError(exception.getClass().toString());
		error.setStatus(exception.getStatus());
		log.debug("Exception handling for ValidationException" + error.getErrorMessage());
		return new ResponseEntity<>(error, HttpStatus.UNPROCESSABLE_ENTITY);
	}

//	@ExceptionHandler(DateValidationException.class)
//	@ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
//	public ResponseEntity<ExceptionResponse> handleValidationException(DateValidationException exception,
//			final HttpServletRequest request) {
//		log.info("Exception handling for DateValidationException");
//		ExceptionResponse error = new ExceptionResponse();
//		error.setErrorMessage(exception.getMessage());
//		error.setRequestedURI(request.getRequestURI());
//		error.setError(exception.getClass().toString());
//		error.setStatus(exception.getStatus());
//		log.debug("Exception handling for DateValidationException" + error.getErrorMessage());
//		return new ResponseEntity<>(error, HttpStatus.UNPROCESSABLE_ENTITY);
//	}

	/* if handleHttpMessageNotReadable throws it will call here -- if employee not found form db*/
	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException exception,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		log.info("Exception handling for handleHttpMessageNotReadable");
		ExceptionResponse error = new ExceptionResponse();
		error.setErrorMessage(MessageContants.JSON_FORMAT_EX);
		error.setRequestedURI(((ServletWebRequest) request).getRequest().getRequestURI());
		error.setError(exception.getClass().toString());
		error.setStatus(HttpStatus.BAD_REQUEST.value());
		log.debug("Exception handling for handleHttpMessageNotReadable" + error.getErrorMessage());
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}

	/* if handleMethodArgumentNotValid throws it will call here -- overrided from ResponseEntityExceptionHandler*/
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException exception,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		log.info("Exception handling for handleHttpMessageNotReadable");
		ExceptionResponse error = new ExceptionResponse();
		
		Map<String, String> errorMap = new HashMap<>();
		exception.getBindingResult().getFieldErrors().forEach(er -> {
			errorMap.put(er.getField(), er.getDefaultMessage());
		});
		error.setErrorMessage("Errors from validation:");
		error.setRequestedURI(((ServletWebRequest) request).getRequest().getRequestURI());
		error.setError(exception.getClass().toString());
		error.setStatus(HttpStatus.BAD_REQUEST.value());
		error.setListOfError(errorMap);
		log.debug("Exception handling for handleMethodArgumentNotValid" + error.getErrorMessage());
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}

}
