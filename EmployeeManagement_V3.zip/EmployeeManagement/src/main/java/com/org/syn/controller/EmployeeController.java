package com.org.syn.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.org.syn.constants.MessageContants;
import com.org.syn.exception.EmployeeNotFoundException;
import com.org.syn.exception.ValidationException;
import com.org.syn.model.request.EmployeeRequest;
import com.org.syn.model.response.EmployeeListResponse;
import com.org.syn.model.response.EmployeeResponse;
import com.org.syn.service.EmployeeService;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
@RequestMapping("/")
public class EmployeeController {
	
	@Autowired
	private EmployeeService empService;
	
	/* getting all employees list based on date of birth sorting */
	@GetMapping("list")
	public EmployeeListResponse getAllEmployeesSortByDOJ(){
		log.debug("called '/list' mapping getAllEmployeesSortByDOJ to rerive all employee data by sorting DOJ.");
		return empService.getAllEmployeesSortByDOJ();
	}

	/* get employee by given id */
	@GetMapping("employee/{id}")
	public EmployeeResponse getEmployeeById(@PathVariable int id) throws EmployeeNotFoundException, ValidationException {
		log.debug("called 'employee/{"+id+"}' mapping");
		return empService.getEmployeeById(id);
	}
	
	/* Adding one employee to Employee and Grade tables with EmployeeRequest */
	@PostMapping("employee/new")
	@ResponseStatus(HttpStatus.CREATED)
	public String addEmployee(@RequestBody @Valid EmployeeRequest empRequest) throws ValidationException {
		log.debug("called 'employee/new' mapping");
		return empService.addEmployee(empRequest);
	}
	
	/* Adding list of employees to Employee and Grade tables with EmployeeRequest */
	@PostMapping("employee/addall")
	@ResponseStatus(HttpStatus.CREATED)
	public String addAllEmployee(@RequestBody List<EmployeeRequest> empList) {
		log.info("called 'employee/addall' mapping");
		empService.addAllEmployee(empList);
		log.info("fetched all employees from DB");
		return MessageContants.EMPLOYEES_ADD_SUCCESS_MESSAGE;
	}
	
	/*
	 * promote the employee, save the changes to DB and return the employee’s details 
	 * To promote an employee from promotion table, 
	 * 1. Score of the employee > 10 
	 * 2. Last Date of Promotion is more than 8 months back. 
	 * 3. should be available in employee and promotion table
	 * ---From promotion table
	 * 1. Increase the rank of the employee by 1 
	 * 2. Change the score of the employee to 0 
	 * 3. Update the Promotion Table to include new Date of Promotion and the Employee Id.
	 *  
	 * To promote an employee from Employee table
	 * 1. Score of the employee > 10
	 * 2. Date of joining is more than 8 months back. 
	 * 3. should not be available in promotion table
	 * ----From Employee table
	 * 1. Increase the rank of the employee by 1 
	 * 2. Change the score of the employee to 0 
	 * 3. insert the Promotion Table to include new Date of Promotion and the Employee Id.
	 */
	
	@GetMapping("employee/promote")
	public EmployeeListResponse promoteEmployee() {
		log.info("called 'employee/promote' mapping");
		return empService.promoteEmployee();
	}
}
