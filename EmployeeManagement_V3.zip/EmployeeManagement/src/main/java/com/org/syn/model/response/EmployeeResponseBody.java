package com.org.syn.model.response;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class EmployeeResponseBody {

	private String firstName;
	private String lastName;
	private LocalDate dateOfBirth;
	private LocalDate joiningDate;
	private int rank;
	private String role;
	
}
