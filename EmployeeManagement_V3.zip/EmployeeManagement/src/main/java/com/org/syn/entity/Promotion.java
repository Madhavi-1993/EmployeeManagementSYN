package com.org.syn.entity;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Promotion {
	@EmbeddedId
	private PromotionId promotionId;
 
	public PromotionId getPromotionId() {
		return promotionId;
	}

	public void setPromotionId(PromotionId promotionId) {
		this.promotionId = promotionId;
	}
	
	
}
