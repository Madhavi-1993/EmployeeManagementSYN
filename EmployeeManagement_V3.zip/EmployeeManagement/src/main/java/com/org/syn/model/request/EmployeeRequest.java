package com.org.syn.model.request;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Positive;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.org.syn.constants.MessageContants;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EmployeeRequest {
	//@NotNull(message =MessageContants.FIRST_NAME_VALIDATION_MESSAGE)
	@NotEmpty(message =MessageContants.FIRST_NAME_VALIDATION_MESSAGE)
	private String firstName;
	private String lastName;
	
	@JsonFormat(pattern = "dd/MM/yyyy")
	@Pattern(regexp = MessageContants.DATE_PATTERN, message=MessageContants.DOB_VALIDATION_MESSAGE)
	private String dateOfBirth;
	
	@JsonFormat(pattern = "dd/MM/yyyy")
	@Pattern(regexp = MessageContants.DATE_PATTERN, message=MessageContants.DOJ_VALIDATION_MESSAGE)
	private String joiningDate;
	
	private double score;
	@Positive(message=MessageContants.RANK_VALIDATION_MESSAGE)
	private int rank;
	@NotEmpty(message=MessageContants.ROLL_VALIDATION_MESSAGE)
	private String role;
}
