package com.org.syn.exception;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class EmployeeNotFoundException extends Exception {

	
	/**
	 * invoke this if employee not found from Employee table
	 */
	private static final long serialVersionUID = -9079454849611061074L;
	private int status;
	private String message;

	public EmployeeNotFoundException(String message) {
		super(message);
	}

}