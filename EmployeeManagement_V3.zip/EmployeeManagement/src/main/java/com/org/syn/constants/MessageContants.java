package com.org.syn.constants;

public class MessageContants {
	public static final String SUCCESS_MESSAGE = "Success";
	public static final String FAIL_MESSAGE = "Fail";
	public static final String SUCCESS_CODE = "200";
	public static final String EMPLOYEES_FOUND = "employee found for Id: ";
	public static final String NO_EMPLOYEES_FOUND = "No employees found.";
	public static final String EMPLOYEE_ID_ERROR = "Id should not be zero or negative value";
	public static final String FIRST_NAME_VALIDATION_MESSAGE = "Employee FirstName can not be null or empty.";
	public static final String DOB_VALIDATION_MESSAGE="Date of Birth should be in yyyy-mm-dd format.";
	public static final String DOJ_VALIDATION_MESSAGE="Joining date should be in yyyy-mm-dd format.";
	public static final String RANK_VALIDATION_MESSAGE="Employee Rank can not be empty or zero.";
	public static final String ROLL_VALIDATION_MESSAGE="Employee Roll can not be null.";
	public static final String EMPLOYEES_ADD_SUCCESS_MESSAGE="All Employees added successfully.";
	public static final String EMPLOYEE_ADD_SUCCESS_MESSAGE = "Employee Added Successfully";
	public static final String NO_ELIGIBLE_EMPLOYEE="No Employees eligible for Promotion.";
	public static final String EMPLOYEE_SIZE="Employee size: ";
	public static final String EMPLOYEE_NOT_FOUND_FOR_ID="Employee not available for this id: ";
	public static final String JSON_FORMAT_EX = "Please check input JSON Format";
	public static final String RANK_ROLE_UNIQUE_CONSTRAIN_VAILATION_EX ="Please check request, Rank and Role unique ConstraintViolation";
	public static final String DATE_PATTERN = "^\\d{4}\\-(0[1-9]|1[012])\\-(0[1-9]|[12][0-9]|3[01])$";
}
