package com.org.syn.config;

import java.util.Collections;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;;

@EnableSwagger2
@Configuration
public class SpringFoxConfig {
	
	/* setting up swagger for Employye management */
	@Bean
	public Docket DockertswaggerConfiguration() {
		return new Docket(DocumentationType.SWAGGER_2)
				.groupName("EmployeeManagement")
				.select()
				.paths(PathSelectors.ant("/**"))
				.build()
				.apiInfo(getName());
	}
	
	private ApiInfo getName() {
		return new ApiInfo("Employee management swagger","Employee Project","V1",null,
				new Contact("EmployeeSwageer", "http://localhost/Employee", "mp@gmail.com")
				,null,null,Collections.emptyList());
	}
}
