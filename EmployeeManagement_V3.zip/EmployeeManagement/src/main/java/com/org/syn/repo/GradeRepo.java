package com.org.syn.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.org.syn.entity.Grade;

@Repository
public interface GradeRepo extends JpaRepository<Grade, Integer>{
		
	/*
	 * @Modifying
	 * 
	 * @Query(value="update Grade g SET g.rank=:rank WHERE g.gradeId=:gradeId") void
	 * updateRankIncrement(@Param("rank") int rank, @Param("gradeId") int gradeId);
	 */
}
