package com.org.syn.model.response;

import java.util.List;

import com.org.syn.entity.Employee;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@AllArgsConstructor
@ToString
@Builder
public class EmployeeListResponse {
	
	private String status;
	private String statusCode;
	private String message;
	private List<Employee> empList;

}
